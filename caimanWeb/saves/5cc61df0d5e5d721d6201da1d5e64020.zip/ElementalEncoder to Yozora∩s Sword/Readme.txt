Place the .pak file in ~mods folder, which should be in 
"EpicLibrary\KH_3\KINGDOM HEARTS III\Content\Paks\~mods" 
where the game is installed.